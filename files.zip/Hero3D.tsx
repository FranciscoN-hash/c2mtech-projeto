import { Suspense, useEffect, useMemo, useRef, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Environment, MeshTransmissionMaterial } from '@react-three/drei';
import { Bloom, ChromaticAberration, DepthOfField, EffectComposer } from '@react-three/postprocessing';
import * as THREE from 'three';

/**
 * C2MTECH — Hero3D
 * -----------------------------------------------------------------------
 * NOTE: this component is intentionally self-contained and isolated from
 * the rest of the layout (see Hero.tsx, which lazy-loads it). Only this
 * file should change for future hero-animation requests.
 *
 * Scene timeline (all times in seconds, driven by a single elapsed clock,
 * mapped 1:1 to the "CENA" briefing):
 *   0.0 – 1.0   SEED       dark scene, glass sphere breathing, particles
 *                          drifting wide and slow, camera dollies in.
 *   1.0 – 2.4   AWAKEN     particles accelerate and converge into the
 *                          sphere.
 *   2.4 – 6.0   FORM       letters assemble in sequence: C -> 2 -> M -> TECH,
 *                          with faint blue spark-lines between particles.
 *   6.0 – 7.5   MATERIALIZE glow particles cross-fade into a metallic,
 *                          bevelled logo (blue C/M, gold 2/TECH).
 *   7.5+        IDLE       sphere + logo settle, ambient particles keep
 *                          orbiting/passing through the glass forever.
 *
 * Mouse (all phases): subtle group tilt, camera parallax, rim-light shift.
 * Scroll: group shrinks, rotates ~15deg and drifts toward the top-left,
 * fading out — read entirely from this component's own bounding box, so
 * no other file needs to change.
 * -----------------------------------------------------------------------
 */

const PHASE_TIMES = { awaken: 1.0, form: 2.4, materialize: 6.0, idle: 7.5 };
const FORM_WINDOW = (PHASE_TIMES.materialize - PHASE_TIMES.form) / 4; // per-letter-group duration

const COLOR_BLUE = new THREE.Color('#00B7FF');
const COLOR_GOLD = new THREE.Color('#FFC93C');
// matches the real C2MTECH mark: C blue, 2 gold, M blue, TECH gold
const GROUP_COLOR = [COLOR_BLUE, COLOR_GOLD, COLOR_BLUE, COLOR_GOLD];

function smoothstep(edge0: number, edge1: number, x: number) {
  const t = THREE.MathUtils.clamp((x - edge0) / (edge1 - edge0), 0, 1);
  return t * t * (3 - 2 * t);
}

// ---------------------------------------------------------------------
// Build the C2MTECH point cloud once (canvas rasterisation -> points).
// Runs on mount only (useMemo, empty deps) — never recomputed.
// ---------------------------------------------------------------------
interface LogoData {
  targets: Float32Array;
  starts: Float32Array;
  groups: Int32Array;
  count: number;
}

function rasterize(text: string, w: number, h: number, fontSize: number, letterSpacing = 0) {
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = '#fff';
  ctx.font = `700 ${fontSize}px Arial, sans-serif`;
  ctx.textBaseline = 'middle';

  const chars = text.split('');
  const widths = chars.map((c) => ctx.measureText(c).width);
  const total = widths.reduce((a, b) => a + b, 0) + letterSpacing * (chars.length - 1);
  let x = w / 2 - total / 2;
  chars.forEach((c, i) => {
    ctx.textAlign = 'left';
    ctx.fillText(c, x, h / 2);
    x += widths[i] + letterSpacing;
  });

  return ctx.getImageData(0, 0, w, h);
}

function buildLogoPoints(): LogoData {
  const pts: { x: number; y: number; group: number }[] = [];
  const step = 3;
  const scale = 0.017;

  // "C", "2", "M" — three individual glyphs, each its own group (0,1,2)
  const letters = ['C', '2', 'M'];
  let cursorX = -2.15;
  letters.forEach((ch, group) => {
    const size = 190;
    const img = rasterize(ch, size, size, size * 0.74);
    for (let y = 0; y < size; y += step) {
      for (let x = 0; x < size; x += step) {
        const idx = (y * size + x) * 4;
        if (img.data[idx] > 128) {
          pts.push({
            x: (x - size / 2) * scale + cursorX,
            y: -(y - size / 2) * scale + 0.5,
            group,
          });
        }
      }
    }
    cursorX += 1.15;
  });

  // "TECH" — single wordmark, group 3
  {
    const w = 620;
    const h = 150;
    const img = rasterize('TECH', w, h, 92, 12);
    const wordScale = scale * 0.6;
    for (let y = 0; y < h; y += step) {
      for (let x = 0; x < w; x += step) {
        const idx = (y * w + x) * 4;
        if (img.data[idx] > 128) {
          pts.push({
            x: (x - w / 2) * wordScale,
            y: -(y - h / 2) * wordScale - 0.95,
            group: 3,
          });
        }
      }
    }
  }

  const count = pts.length;
  const targets = new Float32Array(count * 3);
  const starts = new Float32Array(count * 3);
  const groups = new Int32Array(count);

  for (let i = 0; i < count; i++) {
    targets[i * 3 + 0] = pts[i].x;
    targets[i * 3 + 1] = pts[i].y;
    targets[i * 3 + 2] = (Math.random() - 0.5) * 0.3;
    groups[i] = pts[i].group;

    const r = 3.6 + Math.random() * 2.4;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(Math.random() * 2 - 1);
    starts[i * 3 + 0] = r * Math.sin(phi) * Math.cos(theta);
    starts[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
    starts[i * 3 + 2] = r * Math.cos(phi);
  }

  return { targets, starts, groups, count };
}

// ---------------------------------------------------------------------
// Glass energy sphere — present the whole time (CENA1, CENA5)
// ---------------------------------------------------------------------
function CoreSphere({ elapsedRef }: { elapsedRef: React.MutableRefObject<number> }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((_, delta) => {
    if (!ref.current) return;
    ref.current.rotation.y += delta * 0.06;
    ref.current.rotation.x += delta * 0.015;
    // slow "breathing" scale while still in the SEED phase
    const t = elapsedRef.current;
    const breathe = t < PHASE_TIMES.awaken ? 1 + Math.sin(t * 1.6) * 0.015 : 1;
    ref.current.scale.setScalar(breathe);
  });

  return (
    <mesh ref={ref}>
      <sphereGeometry args={[2.7, 64, 64]} />
      <MeshTransmissionMaterial
        thickness={0.45}
        roughness={0.06}
        transmission={1}
        ior={1.25}
        chromaticAberration={0.025}
        distortion={0.18}
        distortionScale={0.25}
        temporalDistortion={0.1}
        color="#00b7ff"
        backside
        resolution={256}
        samples={2}
      />
    </mesh>
  );
}

// ---------------------------------------------------------------------
// Ambient particle field — always alive (CENA1, CENA2, CENA6)
// ---------------------------------------------------------------------
const AMBIENT_COUNT = 260;

function AmbientParticles({ elapsedRef }: { elapsedRef: React.MutableRefObject<number> }) {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  const particles = useMemo(
    () =>
      Array.from({ length: AMBIENT_COUNT }, () => ({
        radiusFactor: 0.55 + Math.random() * 0.85, // <1 dips inside the glass sphere
        speed: 0.08 + Math.random() * 0.18,
        offset: Math.random() * Math.PI * 2,
        tilt: Math.random() * Math.PI,
        life: Math.random() * Math.PI * 2,
        lifeSpeed: 0.3 + Math.random() * 0.5,
        isGold: Math.random() < 0.3,
      })),
    []
  );

  useEffect(() => {
    const mesh = meshRef.current;
    if (!mesh) return;
    particles.forEach((p, i) => {
      mesh.setColorAt(i, p.isGold ? COLOR_GOLD : COLOR_BLUE);
    });
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  }, [particles]);

  useFrame((_, delta) => {
    const mesh = meshRef.current;
    if (!mesh) return;
    const t = elapsedRef.current;

    // orbit radius shrinks from wide/scattered (SEED) to hugging/crossing
    // the sphere surface (AWAKEN onward) — this alone reads as "particles
    // accelerating and entering the sphere".
    const baseRadius = THREE.MathUtils.lerp(
      5.8,
      3.0,
      smoothstep(PHASE_TIMES.awaken * 0.2, PHASE_TIMES.awaken, t)
    );

    particles.forEach((p, i) => {
      p.life += delta * p.lifeSpeed;
      const r = baseRadius * p.radiusFactor;
      const angle = t * p.speed + p.offset;

      const x = Math.cos(angle) * r;
      const z = Math.sin(angle) * r;
      const y = Math.sin(angle * 0.6 + p.tilt) * r * 0.35;

      dummy.position.set(x, y, z);
      // "some fade out, new ones fade in" — simulated via a breathing
      // scale instead of actually destroying/creating instances
      const pulse = 0.55 + Math.sin(p.life) * 0.45;
      const scale = 0.03 * Math.max(pulse, 0.08);
      dummy.scale.setScalar(scale);
      dummy.rotation.set(0, 0, 0);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    });

    mesh.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, AMBIENT_COUNT]}>
      <sphereGeometry args={[1, 6, 6]} />
      <meshBasicMaterial toneMapped={false} />
    </instancedMesh>
  );
}

// ---------------------------------------------------------------------
// Logo glow particles — the letters being "manufactured" (CENA3, CENA4)
// ---------------------------------------------------------------------
function LogoParticles({
  logo,
  elapsedRef,
}: {
  logo: LogoData;
  elapsedRef: React.MutableRefObject<number>;
}) {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const materialRef = useRef<THREE.MeshBasicMaterial>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  useEffect(() => {
    const mesh = meshRef.current;
    if (!mesh) return;
    for (let i = 0; i < logo.count; i++) {
      mesh.setColorAt(i, GROUP_COLOR[logo.groups[i]]);
    }
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  }, [logo]);

  useFrame(() => {
    const mesh = meshRef.current;
    if (!mesh) return;
    const t = elapsedRef.current;

    // fade the glow particles out once the metal logo has taken over
    const fadeOut = 1 - smoothstep(PHASE_TIMES.materialize, PHASE_TIMES.idle, t);
    if (materialRef.current) materialRef.current.opacity = fadeOut;
    if (fadeOut <= 0.01) return; // skip matrix work entirely once invisible

    const enter = smoothstep(PHASE_TIMES.awaken, PHASE_TIMES.form, t);

    for (let i = 0; i < logo.count; i++) {
      const group = logo.groups[i];
      const tx = logo.targets[i * 3 + 0];
      const ty = logo.targets[i * 3 + 1];
      const tz = logo.targets[i * 3 + 2];
      const sx = logo.starts[i * 3 + 0];
      const sy = logo.starts[i * 3 + 1];
      const sz = logo.starts[i * 3 + 2];

      // stage 1: converge from chaos toward a loose blob near the sphere
      const convergedX = tx * 0.12;
      const convergedY = ty * 0.12;
      const convergedZ = tz * 0.12;

      let x = THREE.MathUtils.lerp(sx, convergedX, enter);
      let y = THREE.MathUtils.lerp(sy, convergedY, enter);
      let z = THREE.MathUtils.lerp(sz, convergedZ, enter);

      // stage 2: each letter group assembles in its own time window
      const groupStart = PHASE_TIMES.form + group * FORM_WINDOW;
      const gp = smoothstep(groupStart, groupStart + FORM_WINDOW, t);
      x = THREE.MathUtils.lerp(convergedX, tx, gp);
      y = THREE.MathUtils.lerp(convergedY, ty, gp);
      z = THREE.MathUtils.lerp(convergedZ, tz, gp);

      // gentle organic jitter that dies out as each letter settles
      const jitter = (1 - gp) * 0.35;
      x += Math.sin(t * 2.1 + i) * jitter * 0.05;
      y += Math.cos(t * 1.7 + i * 1.3) * jitter * 0.05;

      dummy.position.set(x, y, z);
      dummy.scale.setScalar(0.028);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    }

    mesh.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, logo.count]}>
      <sphereGeometry args={[1, 6, 6]} />
      <meshBasicMaterial ref={materialRef} transparent toneMapped={false} />
    </instancedMesh>
  );
}

// ---------------------------------------------------------------------
// Logo metal — the materialised, bevelled, metallic result (CENA4)
// Positions are set once (they never move again), so per-frame cost is
// just a scale animation on the whole instanced mesh — very cheap.
// ---------------------------------------------------------------------
function LogoMetal({ logo, elapsedRef }: { logo: LogoData; elapsedRef: React.MutableRefObject<number> }) {
  const groupRef = useRef<THREE.Group>(null);
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  useEffect(() => {
    const mesh = meshRef.current;
    if (!mesh) return;
    for (let i = 0; i < logo.count; i++) {
      dummy.position.set(logo.targets[i * 3 + 0], logo.targets[i * 3 + 1], logo.targets[i * 3 + 2]);
      dummy.scale.setScalar(0.034); // slightly larger than the glow dots -> reads as "bevel"
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
      mesh.setColorAt(i, GROUP_COLOR[logo.groups[i]]);
    }
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  }, [logo]);

  useFrame((_, delta) => {
    const t = elapsedRef.current;
    const grow = smoothstep(PHASE_TIMES.materialize, PHASE_TIMES.materialize + 1.0, t);
    if (groupRef.current) {
      groupRef.current.scale.setScalar(grow);
      if (t > PHASE_TIMES.idle) groupRef.current.rotation.y += delta * 0.03; // idle shimmer
    }
  });

  return (
    <group ref={groupRef} scale={0}>
      <instancedMesh ref={meshRef} args={[undefined, undefined, logo.count]}>
        <sphereGeometry args={[1, 10, 10]} />
        <meshPhysicalMaterial metalness={1} roughness={0.18} clearcoat={0.7} clearcoatRoughness={0.2} />
      </instancedMesh>
    </group>
  );
}

// ---------------------------------------------------------------------
// Spark lines — small blue electric arcs while letters are forming
// ---------------------------------------------------------------------
const SPARK_SEGMENTS = 22;

function SparkLines({ logo, elapsedRef }: { logo: LogoData; elapsedRef: React.MutableRefObject<number> }) {
  const lineRef = useRef<THREE.LineSegments>(null);
  const positions = useMemo(() => new Float32Array(SPARK_SEGMENTS * 2 * 3), []);
  const geomRef = useRef<THREE.BufferGeometry>(null);
  const lastRefresh = useRef(0);

  useFrame(() => {
    const t = elapsedRef.current;
    const active = t > PHASE_TIMES.form && t < PHASE_TIMES.materialize + 0.4;
    if (lineRef.current) lineRef.current.visible = active;
    if (!active || !geomRef.current) return;

    if (t - lastRefresh.current > 0.12) {
      lastRefresh.current = t;
      for (let i = 0; i < SPARK_SEGMENTS; i++) {
        const a = Math.floor(Math.random() * logo.count);
        const b = Math.floor(Math.random() * logo.count);
        positions[i * 6 + 0] = logo.targets[a * 3 + 0];
        positions[i * 6 + 1] = logo.targets[a * 3 + 1];
        positions[i * 6 + 2] = logo.targets[a * 3 + 2];
        positions[i * 6 + 3] = logo.targets[b * 3 + 0];
        positions[i * 6 + 4] = logo.targets[b * 3 + 1];
        positions[i * 6 + 5] = logo.targets[b * 3 + 2];
      }
      geomRef.current.attributes.position.needsUpdate = true;
    }
  });

  return (
    <lineSegments ref={lineRef}>
      <bufferGeometry ref={geomRef}>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <lineBasicMaterial color="#00B7FF" transparent opacity={0.5} toneMapped={false} />
    </lineSegments>
  );
}

// ---------------------------------------------------------------------
// Lights — key/rim/ambient, subtly reactive to the pointer (CENA7)
// ---------------------------------------------------------------------
function SceneLights() {
  const blueRim = useRef<THREE.PointLight>(null);
  const goldRim = useRef<THREE.PointLight>(null);

  useFrame((state) => {
    const { pointer } = state;
    if (blueRim.current) blueRim.current.intensity = 1.6 + pointer.x * 0.4;
    if (goldRim.current) goldRim.current.intensity = 1.3 + pointer.y * 0.4;
  });

  return (
    <>
      <ambientLight intensity={0.35} />
      <directionalLight position={[3, 5, 4]} intensity={0.6} />
      <pointLight ref={blueRim} position={[4, 2, 4]} color="#00B7FF" intensity={1.6} />
      <pointLight ref={goldRim} position={[-4, -1, 3]} color="#FFC93C" intensity={1.3} />
    </>
  );
}

// ---------------------------------------------------------------------
// Camera + group rig — mouse parallax (CENA7) and scroll dock (CENA8)
// ---------------------------------------------------------------------
function CameraRig({
  groupRef,
  scrollRef,
  elapsedRef,
}: {
  groupRef: React.MutableRefObject<THREE.Group | null>;
  scrollRef: React.MutableRefObject<number>;
  elapsedRef: React.MutableRefObject<number>;
}) {
  useFrame((state, delta) => {
    elapsedRef.current += delta;
    const { pointer, camera } = state;
    const scroll = scrollRef.current;
    const t = elapsedRef.current;

    // slow dolly-in during SEED, gentle idle orbit afterwards
    const dolly = THREE.MathUtils.lerp(9, 7, smoothstep(0, PHASE_TIMES.awaken, t));
    const idleSway = t > PHASE_TIMES.idle ? Math.sin(t * 0.05) * 0.4 : 0;

    camera.position.x += (idleSway + pointer.x * 0.35 - camera.position.x) * 0.04;
    camera.position.y += (0.15 + pointer.y * 0.2 - camera.position.y) * 0.04;
    camera.position.z += (dolly - scroll * 1.2 - camera.position.z) * 0.05;
    camera.lookAt(0, 0, 0);

    const g = groupRef.current;
    if (!g) return;

    const targetRotY = pointer.x * 0.18 + scroll * THREE.MathUtils.degToRad(15);
    const targetRotX = -pointer.y * 0.1 + scroll * 0.12;
    g.rotation.y += (targetRotY - g.rotation.y) * 0.06;
    g.rotation.x += (targetRotX - g.rotation.x) * 0.06;

    const targetScale = Math.max(1 - scroll * 0.82, 0.18);
    g.scale.setScalar(THREE.MathUtils.lerp(g.scale.x || 1, targetScale, 0.08));

    const targetX = -scroll * 2.6;
    const targetY = scroll * 1.7;
    g.position.x += (targetX - g.position.x) * 0.08;
    g.position.y += (targetY - g.position.y) * 0.08;
  });

  return null;
}

// ---------------------------------------------------------------------
// Scene
// ---------------------------------------------------------------------
function Scene({ scrollRef }: { scrollRef: React.MutableRefObject<number> }) {
  const groupRef = useRef<THREE.Group>(null);
  const elapsedRef = useRef(0);
  const logo = useMemo(buildLogoPoints, []);

  return (
    <>
      <SceneLights />
      <group ref={groupRef}>
        <CoreSphere elapsedRef={elapsedRef} />
        <AmbientParticles elapsedRef={elapsedRef} />
        <LogoParticles logo={logo} elapsedRef={elapsedRef} />
        <LogoMetal logo={logo} elapsedRef={elapsedRef} />
        <SparkLines logo={logo} elapsedRef={elapsedRef} />
      </group>
      <CameraRig groupRef={groupRef} scrollRef={scrollRef} elapsedRef={elapsedRef} />
      <Suspense fallback={null}>
        <Environment preset="night" />
      </Suspense>
    </>
  );
}

export default function Hero3D() {
  const containerRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef(0);
  const [reduceMotion] = useState(
    () => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches
  );

  // Scroll progress read from this component's own bounding box — keeps
  // the "dock to header" behaviour fully contained in this file.
  useEffect(() => {
    function onScroll() {
      const el = containerRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const vh = window.innerHeight;
      const raw = 1 - rect.top / vh;
      scrollRef.current = THREE.MathUtils.clamp(raw, 0, 1);
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  if (reduceMotion) {
    // Static, legible fallback — no particle simulation, no postprocessing.
    return (
      <div className="flex h-full w-full items-center justify-center">
        <span className="font-display text-4xl font-extrabold">
          <span className="text-neon">C2M</span>
          <span className="text-gold">TECH</span>
        </span>
      </div>
    );
  }

  return (
    <div ref={containerRef} className="h-full w-full">
      <Canvas dpr={[1, 1.75]} gl={{ antialias: true, powerPreference: 'high-performance' }} camera={{ position: [0, 0, 9], fov: 45 }}>
        <color attach="background" args={['#111111']} />
        <Scene scrollRef={scrollRef} />
        <EffectComposer multisampling={0}>
          <Bloom intensity={0.9} luminanceThreshold={0.22} luminanceSmoothing={0.9} mipmapBlur />
          <ChromaticAberration offset={[0.0006, 0.0006]} />
          <DepthOfField focusDistance={0.015} focalLength={0.02} bokehScale={2} height={480} />
        </EffectComposer>
      </Canvas>
    </div>
  );
}
